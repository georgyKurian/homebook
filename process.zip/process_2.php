<html>
	<head>
	</head>
	<body>
		<?php
			echo "Name :",$_GET["by_name"],"<br>";
			echo "Amount :",$_GET["to_name"],"<br>";
			echo "Description :",$_GET["amount"],"<br>";
			echo "Date :",$_GET["date"],"<br>";
			$con=mysqli_connect("localhost","root","","flat");
			
			// Check connection
			if (mysqli_connect_errno()) {
			  echo "Failed to connect to MySQL: " . mysqli_connect_error();
			}
			$query= "INSERT INTO `flat`.`master_table` (`sl_no`, `name`, `entered_date`, `price`, `description`, `trans_date`) VALUES (NULL, \'".$_GET["name"]."\', \'".$_GET["date"]."\', \'".$_GET["amount"]."\', \'".$_GET["description"]."\', CURRENT_TIMESTAMP);";
			mysqli_query($con,$query);
			
			//
			
			$result = mysqli_query($con,"SELECT * FROM Persons");

			while($row = mysqli_fetch_array($result)) {
			  echo $row['FirstName'] . " " . $row['LastName'];
			  echo "<br>";
			}
			//
			
			mysqli_close($con);
		?>
	</body>
</html>