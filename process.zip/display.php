<!DOCTYPE HTML>
<html>
<head>
</head>

<body style="text-align: center">
<style>
table {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    width: 100%;
    border-collapse: collapse;
}

table td, table th {
    border: 1px solid #98bf21;
}

table th {
    padding :0px 25px;
    background-color: #A7C942;
    color: #ffffff;
}

table tr.alt td {
    color: #000000;
    background-color: #EAF2D3;
}

hr{

background-color:#444;
height:2px;
-webkit-box-shadow: 1px 1px 1px #ffffff;


}
</style>
<div  style="font-size: 25px;;background:red;color:white;margin-bottom: 20px">TRANSACTIONS</div>

<hr>

<form name="input" action="demo_form_action.asp" method="get" style="text-align:left;   ">
<input type="radio" name="type" value="today" checked>Todays Transactions<br>
<input type="radio" name="type" value="duration">Select dates <input type="date" name="date1" value="<?php echo date('Y-m-d'); ?>" > <input type="date" name="date2" value="<?php echo date('Y-m-d'); ?>"><br>
<input type="submit" value="Retrive Data" style="cursor:pointer">
</form>

<hr>

<div >


<table id="customers">
  <tr>
    <th>no </th> <th>name  </th><th>entered_date  </th><th>price </th> <th>descrpition    </th><th>Transaction_date  </th>
  </tr>
  <tr>
    <td>1</td> <td>Abdul  </td><td>10-10-2013  </td><td>112 </td> <td>descrpition_available </td><td>12-34-2014  </td>

  </tr>
  <tr class="alt">
    <td>1</td> <td>Abdul  </td><td>10-10-2013  </td><td>112 </td> <td>descrpition_available </td><td>12-34-2014  </td>
  </tr>
<table>


</div>

</body>

</html>
